Counterbalancing factors: 

Position of barrier: top vs. bottom
Position of balls: green top, blue bottom vs. green bottom, blue top 
First movement: green vs. blue
Order of queries: responsibility first, difficulty second vs. responsibility second, difficulty first (within-subject)